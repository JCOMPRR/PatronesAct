﻿namespace ActPatrones
{
    public interface IVenta
    {
        decimal CalcularTotal();
        List<string> ObtenerProductos();
    }
}
